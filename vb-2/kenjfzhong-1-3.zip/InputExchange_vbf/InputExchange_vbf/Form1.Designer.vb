﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.InputCB = New System.Windows.Forms.ComboBox()
        Me.ExBN = New System.Windows.Forms.Button()
        Me.RecordLB = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'InputCB
        '
        Me.InputCB.Dock = System.Windows.Forms.DockStyle.Top
        Me.InputCB.Font = New System.Drawing.Font("SimSun", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.InputCB.FormattingEnabled = True
        Me.InputCB.Location = New System.Drawing.Point(0, 0)
        Me.InputCB.Name = "InputCB"
        Me.InputCB.Size = New System.Drawing.Size(281, 41)
        Me.InputCB.TabIndex = 0
        '
        'ExBN
        '
        Me.ExBN.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ExBN.Font = New System.Drawing.Font("SimSun", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.ExBN.Location = New System.Drawing.Point(0, 397)
        Me.ExBN.Name = "ExBN"
        Me.ExBN.Size = New System.Drawing.Size(281, 58)
        Me.ExBN.TabIndex = 1
        Me.ExBN.Text = "Exchange"
        Me.ExBN.UseVisualStyleBackColor = True
        '
        'RecordLB
        '
        Me.RecordLB.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RecordLB.Font = New System.Drawing.Font("SimSun", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.RecordLB.FormattingEnabled = True
        Me.RecordLB.ItemHeight = 33
        Me.RecordLB.Location = New System.Drawing.Point(0, 41)
        Me.RecordLB.Name = "RecordLB"
        Me.RecordLB.Size = New System.Drawing.Size(281, 356)
        Me.RecordLB.TabIndex = 2
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(281, 455)
        Me.Controls.Add(Me.RecordLB)
        Me.Controls.Add(Me.ExBN)
        Me.Controls.Add(Me.InputCB)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents InputCB As ComboBox
    Friend WithEvents ExBN As Button
    Friend WithEvents RecordLB As ListBox
End Class
