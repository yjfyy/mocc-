﻿Option Explicit On
'窗体上建立一个简单组合框，在组合框的文本框输入数字字符，
'按回车键后加入到组合框的列表框内，单击”交换”命令按钮，
'将列表框中最小值项目和第0个项目交换；
'最大值项目与最后项目交换
'以“昵称-1-3”为项目名保存。项目完成后，将整个项目文件夹压缩成昵称-1-3.rar，以附件形式提交。

Public Class Form1
    Private Sub InputCB_KeyPress(sender As Object, e As KeyPressEventArgs) Handles InputCB.KeyPress
        Select Case e.KeyChar
            Case "0" To "9", vbBack
            Case "-"
                If InputCB.Text <> "" Then e.Handled = True
            Case vbCr
                RecordLB.Items.Add(InputCB.Text)
                InputCB.Text = ""
            Case Else
                e.Handled = True
        End Select

    End Sub

    Private Sub ExBN_Click(sender As Object, e As EventArgs) Handles ExBN.Click
        If RecordLB.Items.Count < 1 Then
            MsgBox("Please input more numbers!")
            Exit Sub
        End If

        Dim maxI!, minI!, FI!, TI!
        For FI = 0 To RecordLB.Items.Count - 1
            TI = RecordLB.Items(FI)
            If RecordLB.Items(maxI) < TI Then maxI = FI
            If RecordLB.Items(minI) > TI Then minI = FI
        Next

        If minI <> 0 Then
            TI = RecordLB.Items(minI)
            RecordLB.Items.RemoveAt(minI)
            RecordLB.Items.Insert(0, TI)
        End If

        If maxI <> RecordLB.Items.Count - 1 Then
            If maxI < minI Then maxI = maxI + 1
            TI = RecordLB.Items(maxI)
            RecordLB.Items.RemoveAt(maxI)
            RecordLB.Items.Add(TI)
        End If
    End Sub

End Class
