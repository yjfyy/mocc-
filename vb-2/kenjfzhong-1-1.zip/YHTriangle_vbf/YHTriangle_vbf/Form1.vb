﻿Option Explicit On
'输入整数n，显示出具有n行的杨辉三角形,'以“昵称-1-1”为项目名保存。
'项目完成后， 将整个项目文件夹压缩成“昵称-1-1.rar”， 以附件形式提交。
'提示：
'① 定义一个二维数组，数组大小与文本框中输入的n有关；
'② 对下三角各元素进行设置第一列及对角线上的元素均为1；
'其余每一个元素正好等于它上面一行的同一列和前一列的两个元素之和。
'即a(i, j) = a(i - 1, j - 1) + a(i - 1, j)。
'③ 利用Space(4-Len(Trim(a(I,j))))函数定每列输出宽度为4，使得列对齐。

Public Class Form1
    Private Sub InputTB_KeyPress(sender As Object, e As KeyPressEventArgs) Handles InputTB.KeyPress
        Select Case e.KeyChar
            Case "0"
                If InputTB.Text = "" Then e.Handled = True
            Case "1" To "9", vbBack
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub InputTB_TextChanged(sender As Object, e As EventArgs) Handles InputTB.TextChanged
        If InputTB.Text <> "" Then _
            ResultLL.Text = process(CByte(InputTB.Text))
    End Sub

    Private Function process$(ByVal lines!)
        If lines >= 15 Then
            process = "Too much lines!" & vbLf & vbLf & vbLf & vbLf &
                vbLf & vbLf & vbLf & vbLf & Space(37)
            Return process
        End If
        process = ""
        Dim i!, j!, arr(lines, lines)

        For i = 1 To lines
            For j = 1 To lines
                If i = j Then
                    arr(i, j) = 1
                    process = process & arr(i, j)
                ElseIf j = 1 Then
                    arr(i, j) = 1
                    process = process & arr(i, j) & Space(3)
                ElseIf i > j Then
                    arr(i, j) = arr(i - 1, j - 1) + arr(i - 1, j)
                    process = process & arr(i, j) & Space(4 - Len(Trim(arr(i, j))))
                End If
            Next j
            process = process & vbLf
        Next i

        If lines < 10 Then
            For i = 1 To 9 - lines
                process = process & vbLf
            Next
            process = process & Space(37)
        End If

        Erase arr
    End Function

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ResultLL.Text = vbLf & vbLf & vbLf & vbLf & vbLf & vbLf & vbLf & vbLf & vbLf &
            Space(37)
    End Sub
End Class
