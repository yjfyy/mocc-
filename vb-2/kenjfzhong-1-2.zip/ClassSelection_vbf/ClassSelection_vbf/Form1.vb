﻿Option Explicit On
'设计一个选课程序, 它包含2个列表框
'左边为已开设的课程名称，通过Form1_Load事件加入，并且设置了排序；
'当单击某课程名称后，该课程加入到右边列表框，并从左边列表框中删除。
'当右边课程数超过5门时不允许再加入。
'以“昵称-1-2”为项目名保存。项目完成后，将整个项目文件夹压缩成昵称-1-2.rar

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
        With ClassLB.Items
            .Add("数据库技术与应用")
            .Add("多媒体技术与应用")
            .Add("网络技术与应用")
            .Add("硬件技术基础")
            .Add("软件技术基础")
            .Add("大学计算机基础")
            .Add("C/C++程序设计")
            .Add("VB程序设计")
            .Add("Web程序设计")
        End With
        ClassLB.Sorted = True
    End Sub

    Private Sub ClassLB_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ClassLB.SelectedIndexChanged
        If ClassLB.SelectedIndex <> -1 Then
            If SelectedLB.Items.Count < 5 Then
                SelectedLB.Items.Add(CStr(ClassLB.SelectedItem))
                ClassLB.Items.RemoveAt(ClassLB.SelectedIndex)
            Else
                MsgBox("选课超过5门, 不能再选")
            End If
        End If

    End Sub
End Class
