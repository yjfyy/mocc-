﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ClassLA = New System.Windows.Forms.Label()
        Me.SelectedLA = New System.Windows.Forms.Label()
        Me.ClassLB = New System.Windows.Forms.ListBox()
        Me.SelectedLB = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'ClassLA
        '
        Me.ClassLA.AutoSize = True
        Me.ClassLA.Font = New System.Drawing.Font("SimSun", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.ClassLA.Location = New System.Drawing.Point(13, 13)
        Me.ClassLA.Name = "ClassLA"
        Me.ClassLA.Size = New System.Drawing.Size(321, 37)
        Me.ClassLA.TabIndex = 0
        Me.ClassLA.Text = "Class selection:"
        '
        'SelectedLA
        '
        Me.SelectedLA.AutoSize = True
        Me.SelectedLA.Font = New System.Drawing.Font("SimSun", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.SelectedLA.Location = New System.Drawing.Point(348, 13)
        Me.SelectedLA.Name = "SelectedLA"
        Me.SelectedLA.Size = New System.Drawing.Size(340, 37)
        Me.SelectedLA.TabIndex = 0
        Me.SelectedLA.Text = "Selected Classes:"
        '
        'ClassLB
        '
        Me.ClassLB.Font = New System.Drawing.Font("SimSun", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.ClassLB.FormattingEnabled = True
        Me.ClassLB.ItemHeight = 37
        Me.ClassLB.Location = New System.Drawing.Point(20, 63)
        Me.ClassLB.Name = "ClassLB"
        Me.ClassLB.Size = New System.Drawing.Size(314, 374)
        Me.ClassLB.TabIndex = 1
        '
        'SelectedLB
        '
        Me.SelectedLB.Font = New System.Drawing.Font("SimSun", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.SelectedLB.FormattingEnabled = True
        Me.SelectedLB.ItemHeight = 37
        Me.SelectedLB.Location = New System.Drawing.Point(355, 63)
        Me.SelectedLB.Name = "SelectedLB"
        Me.SelectedLB.Size = New System.Drawing.Size(314, 374)
        Me.SelectedLB.TabIndex = 1
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(697, 458)
        Me.Controls.Add(Me.SelectedLB)
        Me.Controls.Add(Me.ClassLB)
        Me.Controls.Add(Me.SelectedLA)
        Me.Controls.Add(Me.ClassLA)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ClassLA As Label
    Friend WithEvents SelectedLA As Label
    Friend WithEvents ClassLB As ListBox
    Friend WithEvents SelectedLB As ListBox
End Class
